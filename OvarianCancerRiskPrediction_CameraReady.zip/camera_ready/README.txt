Camera-ready source package
===========================

Paper: "External Validation of an Interpretable Integer Scorecard versus
        Logistic Regression and Tree Ensembles for Ovarian Cancer
        Risk Prediction"

Contents
--------
  main.tex         Primary LaTeX document (all text, tables, math)
  figures/
    fig1_auroc.png        Figure 1: external validation AUROC ladder (100 complete cases)
    fig2_cons.png         Figure 2: decision curve analysis (West China, N = 380)
    fig3_regime_col.png   Figure 3: simulation regime map
  IEEEtran.cls     Document class (IEEEtran v1.8b, LaTeX Project Public License),
                   included for convenience; all other packages are standard
                   TeX Live: cite, url, amsmath, amssymb, newtxtext, newtxmath,
                   graphicx, booktabs, array.

Bibliography
------------
References are embedded in main.tex via thebibliography (15 entries);
no separate .bib/.bbl file is used.

Build instructions
------------------
  pdflatex main.tex
  pdflatex main.tex     (second pass for cross-references)

Expected output: 5 pages (IEEE conference format), no errors or
overfull warnings.
